INSERT INTO Subjects 
	(id, subject, clickThroughCount) 
VALUES 
	(1, 'algorithms and data structures', 0),
	(2, 'automata theory', 0),
	(3, 'calculus 1 (differential)', 0),
	(4, 'calculus 2 (integral)', 0),
	(5, 'computer architecture', 0),
	(6, 'digital logic', 0),
	(7, 'discrete mathematics', 0),
	(8, 'introductory programming', 0),
	(9, 'linear algebra', 0),
	(10, 'machine learning', 0),
	(11, 'object oriented programming', 0),
	(12, 'operating system concepts', 0),	
	(13, 'organization of programming languages', 0),
	(14, 'physics mechanics and heat', 0),
	(15, 'physics electromagnetism and waves', 0),
	(16, 'probability and statistics', 0),
	(17, 'software engineering', 0);