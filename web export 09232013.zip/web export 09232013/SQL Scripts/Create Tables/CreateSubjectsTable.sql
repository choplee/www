CREATE TABLE Subjects
(
id INT NOT NULL PRIMARY KEY,
subject VARCHAR(256),
creditToID INT,
clickThroughCount INT
);